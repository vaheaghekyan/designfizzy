<?php 
/*
* List of custom post type for dentistry
*/

add_action('init', 'dentistry_slider_register');

function dentistry_slider_register() {
    register_post_type('slider', array(
        'label' => 'Slider',
        'description' => '',
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'capability_type' => 'post',
        'map_meta_cap' => true,
        'hierarchical' => true,
        'rewrite' => array('slug' => 'slider', 'with_front' => true),
        'query_var' => true,
        'menu_position' => '500',        
        'menu_icon'   => 'dashicons-images-alt2',
        'supports' => array('title', 'thumbnail',  'page-attributes'),
        'labels' => array(
            'name' => 'Slider',
            'singular_name' => 'Slider',
            'menu_name' => 'Slider',
            'add_new' => 'Add Slider',
            'add_new_item' => 'Add New Slider',
            'edit' => 'Edit Slider',
            'edit_item' => 'Edit Slider',
            'new_item' => 'New Slider',
            'view' => 'View Slider',
            'view_item' => 'View Slider',
            'search_items' => 'Search Slider',
            'not_found' => 'No Slider Found',
            'not_found_in_trash' => 'No Slider Found in Trash',
            'parent' => 'Parent Slider',
        )
    ));
}

// Custom Doctor post

add_action('init', 'dentistry_doctor_register');

function dentistry_doctor_register() {
    register_post_type('doctor', array(
        'label' => 'Doctor',
        'description' => '',
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'capability_type' => 'post',
        'map_meta_cap' => true,
        'hierarchical' => false,
        'rewrite' => array('slug' => 'doctor', 'with_front' => true),
        'query_var' => true,
        'menu_position' => '500',        
        'menu_icon'   => 'dashicons-businessman',
        'supports' => array('title', 'editor', 'excerpt', 'custom-fields', 'thumbnail',  'page-attributes'),
        'labels' => array(
            'name' => '',
            'singular_name' => 'Doctor',
            'menu_name' => 'Doctor',
            'add_new' => 'Add Doctor',
            'add_new_item' => 'Add New Doctor',
            'edit' => 'Edit Doctor',
            'edit_item' => 'Edit Doctor',
            'new_item' => 'New Doctor',
            'view' => 'View Doctor',
            'view_item' => 'View Doctor',
            'search_items' => 'Search Doctor',
            'not_found' => 'No Doctor Found',
            'not_found_in_trash' => 'No Doctor Found in Trash',
            'parent' => 'Parent Doctor',
        )
    ));
}

// Custom Service post

add_action('init', 'dentistry_services_register');

function dentistry_services_register() {
    register_post_type('service', array(
        'label' => 'Service',
        'description' => '',
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'capability_type' => 'post',
        'map_meta_cap' => true,
        'hierarchical' => false,
        'rewrite' => array('slug' => 'service', 'with_front' => true),
        'query_var' => true,
        'menu_position' => '500',        
        'menu_icon'   => 'dashicons-smiley',
        'supports' => array('title', 'editor', 'excerpt', 'custom-fields', 'thumbnail',  'page-attributes'),
        'labels' => array(
            'name' => '',
            'singular_name' => 'Service',
            'menu_name' => 'Service',
            'add_new' => 'Add Service',
            'add_new_item' => 'Add New Service',
            'edit' => 'Edit Service',
            'edit_item' => 'Edit Service',
            'new_item' => 'New Service',
            'view' => 'View Service',
            'view_item' => 'View Service',
            'search_items' => 'Search Service',
            'not_found' => 'No Service Found',
            'not_found_in_trash' => 'No Service Found in Trash',
            'parent' => 'Parent Service',
        )
    ));
}


// After_Before gallery  post

add_action('init', 'dentistry_after_before_register');

function dentistry_after_before_register() {
    register_post_type('gallery', array(
        'label' => 'Before-After',
        'description' => 'Before-After',
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'capability_type' => 'post',
        'map_meta_cap' => true,
        'hierarchical' => true,
        'show_in_nav_menus' => true,         
        'rewrite' => array('slug' => 'gallery', 'with_front' => true),
        'query_var' => true,
        'menu_position' => '5',
        'menu_icon'   => 'dashicons-format-gallery',
        'supports' => array('title', 'editor','thumbnail', 'page-attributes'),
        'labels' => array(
            'name' => 'Before-After',
            'singular_name' => 'Before-After',
            'menu_name' => 'Before-After',
            'add_new' => 'Add Before-After',
            'add_new_item' => 'Add New Before-After',
            'edit' => 'Edit Before-After',
            'edit_item' => 'Edit Before-After',
            'new_item' => 'New Before-After',
            'view' => 'View Before-After',
            'view_item' => 'View Before-After',
            'search_items' => 'Search Before-After',
            'not_found' => 'No Before-After Found',
            'not_found_in_trash' => 'No Before-After Found in Trash',
            'parent' => 'Parent Before-After',
        )
    ));
}

// Custom Testimonial post

add_action('init', 'dentistry_testimonial_register');

function dentistry_testimonial_register() {
    register_post_type('testimonial', array(
        'label' => 'Testimonial',
        'description' => '',
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'capability_type' => 'post',
        'map_meta_cap' => true,
        'hierarchical' => true,
        'rewrite' => array('slug' => 'testimonial', 'with_front' => true),
        'query_var' => true,
        'menu_position' => '600',        
        'menu_icon'   => 'dashicons-testimonial',
        'supports' => array('title', 'page-attributes','thumbnail',),		
        'labels' => array(
            'name' => 'Testimonial',
            'singular_name' => 'Testimonial',
            'menu_name' => 'Testimonial',
            'add_new' => 'Add Testimonial',
            'add_new_item' => 'Add New Testimonial',
            'edit' => 'Edit Testimonial',
            'edit_item' => 'Edit Testimonial',
            'new_item' => 'New Testimonial',
            'view' => 'View Testimonial',
            'view_item' => 'View Testimonial',
            'search_items' => 'Search Testimonial',
            'not_found' => 'No Testimonial Found',
            'not_found_in_trash' => 'No Testimonial Found in Trash',
            'parent' => 'Parent Testimonial',
        )
    ));
}

// Custom Career post

add_action('init', 'dentistry_career_register');

function dentistry_career_register() {
    register_post_type('career', array(
        'label' => 'Career',
        'description' => '',
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'capability_type' => 'post',
        'map_meta_cap' => true,
        'hierarchical' => true,
        'rewrite' => array('slug' => 'career', 'with_front' => true),
        'query_var' => true,
        'menu_position' => '1200',        
        'menu_icon'   => 'dashicons-welcome-learn-more',
        'supports' => array('title','excerpt', 'editor','thumbnail', 'page-attributes'),
        'labels' => array(
            'name' => 'Career',
            'singular_name' => 'Career',
            'menu_name' => 'Career',
            'add_new' => 'Add Career',
            'add_new_item' => 'Add New Career',
            'edit' => 'Edit Career',
            'edit_item' => 'Edit Career',
            'new_item' => 'New Career',
            'view' => 'View Career',
            'view_item' => 'View Career',
            'search_items' => 'Search Career',
            'not_found' => 'No Career Found',
            'not_found_in_trash' => 'No Career Found in Trash',
            'parent' => 'Parent Career',
        )
    ));
}


// Custom FAQ post

add_action('init', 'dentistry_faq_register');

function dentistry_faq_register() {

    register_post_type('faq', array(
        'label' => 'FAQ',
        'description' => '',
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => false,         
        'capability_type' => 'post',
        'map_meta_cap' => true,
        'hierarchical' => false,
        'rewrite' => array('slug' => 'faq', 'with_front' => true),
        'query_var' => true,
        'menu_position' => '5',
        'menu_icon'   => 'dashicons-editor-help',
        'supports' => array('title', 'page-attributes'),
		'has_archive' => 'faq',		
        'labels' => array(
            'name' => 'FAQ',
            'singular_name' => 'FAQ',
            'menu_name' => 'FAQ',
            'add_new' => 'Add FAQ',
            'add_new_item' => 'Add New FAQ',
            'edit' => 'Edit',
            'edit_item' => 'Edit FAQ',
            'new_item' => 'New FAQ',
            'view' => 'View FAQ',
            'view_item' => 'View FAQ',
            'search_items' => 'Search FAQ',
            'not_found' => 'No FAQ Found',
            'not_found_in_trash' => 'No FAQ Found in Trash',
            'parent' => 'Parent FAQ',
        )
    ));
}
function faq_taxonomy() {
	register_taxonomy(
		'faq_categories',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
		'faq',   		 //post type name
		array(
			'hierarchical' 		=> true,
			'label' 			=> 'Category',  //Display name
			'query_var' 		=> true,
			'rewrite'			=> array(
					'slug' 			=> 'faq', // This controls the base slug that will display before each term
					'with_front' 	=> false // Don't display the category base before
					)
			)
		);
}
add_action( 'init', 'faq_taxonomy');
?>