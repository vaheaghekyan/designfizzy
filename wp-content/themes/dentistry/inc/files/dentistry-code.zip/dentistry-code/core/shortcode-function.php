<?php 

/********************************************/
/*
/*		Plugin shortcode for p and br tags
/*
/********************************************/

function dentistry_plugin_fix_shortcodes($content){   
    $array = array (
        '<p>[' => '[', 
        ']</p>' => ']', 
        ']<br />' => ']'
    );

    $content = strtr($content, $array);
    return $content;
}
add_filter('the_content', 'dentistry_plugin_fix_shortcodes');

/********************************************/
/*
/*		Row
/*
/********************************************/

add_shortcode( 'row', 'dentistry_plugin_sc_row' );
function dentistry_plugin_sc_row( $atts, $content ){	
    return sprintf( 
      '<div class="row">%s</div>',
      do_shortcode(str_replace("<br />", "", $content))
    );
}

/********************************************/
/*
/*		Inner Row
/*
/********************************************/

add_shortcode( 'inner-row', 'dentistry_plugin_sc_inner_row' );
function dentistry_plugin_sc_inner_row( $atts, $content ){	
    return sprintf( 
      '<div class="row">%s</div>',
      do_shortcode(str_replace("<br />", "", $content))
    );
}
/********************************************/
/*
/*		Container
/*
/********************************************/

add_shortcode( 'container', 'dentistry_plugin_sc_container' );
function dentistry_plugin_sc_container( $atts, $content ){	
    return sprintf( 
      '<div class="container">%s</div>',
      do_shortcode(str_replace("<br />", "", $content))
    );
}

/********************************************/
/*
/*		Icon
/*
/********************************************/

add_shortcode( 'icon', 'dentistry_plugin_sc_icon' );
function dentistry_plugin_sc_icon( $atts, $content ){	
    return sprintf( 
      '<div class="%s"><i class="%s" style="color:%s"></i></div>',
       $atts['class'],
       $atts['icon'],
       $atts['color'],      
      do_shortcode( str_replace("<br />", "", $content) )
    );
}

/********************************************/
/*
/*		FULL WIDTH.
/*
/********************************************/

add_shortcode( 'full', 'dentistry_plugin_sc_full' );
function dentistry_plugin_sc_full( $atts, $content = null ){	    
    return sprintf( 
      '<div class="%s">%s</div>',
       $atts['class'],
      do_shortcode(str_replace("<br />", "", $content))
    );
}

/********************************************/
/*
/*		TP BOX.
/*
/********************************************/

add_shortcode( 'tp-box', 'dentistry_plugin_sc_tp_box' );
function dentistry_plugin_sc_tp_box( $atts, $content = null ){	    
    return sprintf( 
      '<div class="%s">%s</div>',
       $atts['class'],
      do_shortcode(str_replace("<br />", "", $content))
    );
}

/********************************************/
/*
/*		TP INNER BOX.
/*
/********************************************/

add_shortcode( 'tp-inner-box', 'dentistry_plugin_sc_tp_inner_box' );
function dentistry_plugin_sc_tp_inner_box( $atts, $content = null ){	    
    return sprintf( 
      '<div class="%s">%s</div>',
       $atts['class'],
      do_shortcode(str_replace("<br />", "", $content))
    );
}

/********************************************/
/*
/*		TP Color BOX.
/*
/********************************************/

add_shortcode( 'tp-light-box', 'dentistry_plugin_sc_tp_light_box' );
function dentistry_plugin_sc_tp_light_box( $atts, $content = null ){	    
    return sprintf( 
      '<div class="tp-light-boxes">%s</div>',
      do_shortcode(str_replace("<br />", "", $content))
    );
}

/********************************************/
/*
/*		COLUMN.
/*
/********************************************/

add_shortcode( 'column', 'dentistry_plugin_sc_column' );
function dentistry_plugin_sc_column( $atts, $content ){	
	$atts = shortcode_atts( array(
      "md" => false,
      "class" => false,	  
	), $atts );

	$class  = ( $atts['md'] ) ? $atts['md'] : '';
	$custom_class  = ( $atts['class'] ) ? ' '.$atts['class'] : '';	
	
    return sprintf( 
      '<div class="col-md-%s%s">%s</div>',
       esc_attr($class),
       esc_attr($custom_class),
      do_shortcode( str_replace("<br />", "", force_balance_tags($content)))
    );
}

/********************************************/
/*
/*		INNER COLUMN.
/*
/********************************************/

add_shortcode( 'inner-column', 'dentistry_plugin_sc_inner_column' );
function dentistry_plugin_sc_inner_column( $atts, $content ){	
	$atts = shortcode_atts( array(
      "md" => false,
	), $atts );

	$class  = ( $atts['md'] ) ? $atts['md'] : '';
	
    return sprintf( 
      '<div class="col-md-%s">%s</div>',
       esc_attr($class),
      do_shortcode( str_replace("<br />", "", force_balance_tags($content)))
    );
}

/********************************************/
/*
/*		UL.
/*
/********************************************/

add_shortcode( 'ul', 'dentistry_plugin_sc_ul' );
function dentistry_plugin_sc_ul( $atts, $content ){	
    return sprintf( 
      '<ul class="%s list-view">%s</ul>',
	  $atts['class'],
      do_shortcode(str_replace("<br />", "", $content) )
    );
}

/********************************************/
/*
/*		OL.
/*
/********************************************/

add_shortcode( 'ol', 'dentistry_plugin_sc_ol' );
function dentistry_plugin_sc_ol( $atts, $content ){	
    return sprintf( 
      '<ol class="list-view">%s</ol>',
      do_shortcode( str_replace("<br />", "", $content) )
    );
}

/********************************************/
/*
/*		LI.
/*
/********************************************/

add_shortcode( 'li', 'dentistry_plugin_sc_li' );
function dentistry_plugin_sc_li( $atts, $content ){ 
    return sprintf( 
      '<li>%s</li>',
      do_shortcode( str_replace("<br />", "", force_balance_tags($content)) )
    );
}

/********************************************/
/*
/*		DIVIDER.
/*
/********************************************/

add_shortcode( 'divi', 'dentistry_plugin_sc_divi' );
function dentistry_plugin_sc_divi( $atts, $content ){	
    
	if(!empty($atts['class']))
	{
		$classes=$atts['class'];
	}
	else
	{
		$classes="divi";
	}

    return sprintf( 
      '<div class="%s"> %s </div>',
      $classes,
      do_shortcode( $content )
    );
}

/********************************************/
/*
/*		BUTTON.
/*
/********************************************/

add_shortcode( 'button', 'dentistry_plugin_sc_button' );
function dentistry_plugin_sc_button( $atts, $content ){	
    
	if(!empty($atts['class']))
	{
		$classes=$atts['class'];
	}
	else
	{
		$classes="btn tp-btn-default";
	}
	

	if(!empty($atts['target']))
	{
		$target=$atts['target'];
	}
	else
	{
		$target="_self";
	}	

    return sprintf( 
      '<a href="%s" class="%s" target="%s"> %s </a>',
	  $atts['url'],
      $classes,
      $target,
      do_shortcode( str_replace("<br />", "", $content) )
    );
}

/********************************************/
/*
/*    Iconbox
/*
/********************************************/

add_shortcode( 'iconbox', 'dentistry_plugin_sc_iconbox' );
function dentistry_plugin_sc_iconbox( $atts, $content ){  
    if($atts['layout']=="icon-box-left")
    {
      return sprintf( 
        '<div class="tp-feature-block"><i class="fa %s feature-icon"></i><h2 class="item-title">%s</h2><p>%s</p></div>',
         $atts['icon'],
         $atts['title'],      
        do_shortcode( $content )
      );
    }
    else if($atts['layout']=="icon-box-center")
    {
      return sprintf( 
        '<div class="tp-feature-block text-center"><i class="fa %s feature-icon"></i><h2 class="item-title">%s</h2><p>%s</p></div>',
         $atts['icon'],
         $atts['title'],      
        do_shortcode( $content )
      );
    }    
    else if($atts['layout']=="icon-box-right")
    {
      return sprintf( 
        '<div class="tp-feature-block text-right"><i class="fa %s feature-icon"></i><h2 class="item-title">%s</h2><p>%s</p></div>',
         $atts['icon'],
         $atts['title'],      
        do_shortcode( $content )
      );
    }    

}

/********************************************/
/*
/*		Alert
/*
/********************************************/

add_shortcode( 'alert', 'dentistry_plugin_sc_alert' );
function dentistry_plugin_sc_alert( $atts, $content ){	
    
	if(!empty($atts['class']))
	{
		$classes=$atts['class'];
	}
	else
	{
		$classes="alert-standard";
	}

    return sprintf( 
      '<div class="alert %s alert-dismissible"><button aria-label="Close" data-dismiss="alert" class="close" type="button">
                    <span aria-hidden="true">×</span>
                </button> %s </div>',
      $classes,
      do_shortcode( str_replace("<br />", "", $content) )
    );
}

/********************************************/
/*
/*    Section
/*
/********************************************/

add_shortcode( 'section', 'dentistry_plugin_sc_section' );
function dentistry_plugin_sc_section( $atts, $content ){
   extract(shortcode_atts(array(
    'title' => 'Collapse',
    'id'  => false,
    'class' => false,
  ), $atts));
  

  $GLOBALS['section'][] = array( 
    'title'   =>  esc_attr($title) ,
    'id'    =>  esc_attr($id),
    'class'   =>  esc_attr($class) ,
    'content' =>  $content ,
  );

  $id  = "collapse-id-".$GLOBALS['collapsibles_count'];
  
    foreach( $GLOBALS['section'] as $tab ){     
    $class = ( !empty($tab['class']) && $tab['class']=="active" ) ? "panel-collapse collapse in"  : "panel-collapse collapse";    
    $__title = preg_replace('/[^a-zA-Z0-9._\-]/', '', strtolower($tab['title'])  );   
    $return = sprintf( "\n".'    
     <div class="panel panel-default">
      <div class="panel-heading">
          <h4 class="panel-title">    
            <a data-toggle="collapse" data-parent="#%s" href="#%s">%s </a>
          </h4>
      </div>      
      <div id="%s" class="%s">
          <div class="panel-body">             
          %s
          </div>
      </div>      
    </div>'."\n" , 
      $id, $__title, $tab['title'], $__title, $class, $tab['content']
    );    
    } // foreach    

  return do_shortcode($return);
  
}// function ending

/********************************************/
/*
/*    Accordion
/*
/********************************************/

add_shortcode( 'accordion', 'dentistry_plugin_sc_accordion' );
function dentistry_plugin_sc_accordion( $atts, $content ){ 
  
  if(isset( $GLOBALS['collapsibles_count'] )) {
    $GLOBALS['collapsibles_count']++;
  }else {
    $GLOBALS['collapsibles_count'] = 0; 
  }

  $id  = "collapse-id-".$GLOBALS['collapsibles_count'];

  return  do_shortcode(sprintf('<div class="tp-accordion check-accordion"><div class="panel-group" id="%s"> %s </div></div> ', esc_attr($id), $content));
}

/********************************************/
/*
/*    Bootstrap Tabs.
/*
/********************************************/

add_shortcode( 'tab', 'dentistry_plugin_sc_tabs' );
function dentistry_plugin_sc_tabs( $atts, $content ){
  extract(shortcode_atts(array(
    'title' => 'Tab',
    'class' => false,
  ), $atts));
    
   $x = isset($GLOBALS['tab_count'])?$GLOBALS['tab_count']:0; 
   $GLOBALS['tab_count'] = isset($GLOBALS['tab_count'])?$GLOBALS['tab_count']:0;      

   $GLOBALS['tabs'][$GLOBALS['tabs_count']][$x] = array( 
      'title'   => esc_attr($title),
      'class'   => esc_attr($class),
      'content'   => $content,
   );
     
   $GLOBALS['tab_count']++;
}

/********************************************/
/*
/*    Tabgroup 
/*
/********************************************/

add_shortcode( 'tabgroup', 'dentistry_plugin_sc_tabgroup' );
function dentistry_plugin_sc_tabgroup( $atts, $content ){
  
    if( isset( $GLOBALS['tabs_count'] ) )
      $GLOBALS['tabs_count']++;
    else
      $GLOBALS['tabs_count'] = 0;

  do_shortcode( $content ); 

  if( is_array( $GLOBALS['tabs'][$GLOBALS['tabs_count']] ) ){
    
    $tabs=array();
    $panes=array();
    
    foreach( $GLOBALS['tabs'][$GLOBALS['tabs_count']] as $tab ){

    $panes_class  = ( !empty($tab["class"]) &&  $tab['class'] == "active" ) ? 'tab-pane active' : 'tab-pane';
    $__title = preg_replace('/[^a-zA-Z0-9._\-]/', '', strtolower($tab['title'])  );   
    $tabs[] = '<li  role="presentation" class="'.$tab['class'].'" >
            <a href="#'.$__title.'" data-toggle="tab">'.$tab['title'].'</a>
          </li>';
    $panes[] = sprintf( '<div class="%s" id="%s"> %s </div>',esc_attr($panes_class),esc_attr($__title), $tab['content']  );
    }

    $return = "\n".'<div role="tabpanel">
              <ul role="tablist" class="nav nav-tabs">'
                .implode( "\n", $tabs ).
              '</ul>'."\n".
              '<div class="tab-content product-tab">'
                  .implode( "\n", $panes ).
              '</div>
            </div>'."\n";   
  } 
  return do_shortcode( sprintf('<div class="st-tab"> %s </div>',  str_replace("<br />","",$return)));
}

/********************************************/
/*
/*    FAQs
/*
/********************************************/

add_shortcode( 'question', 'dentistry_plugin_sc_question' );
function dentistry_plugin_sc_question( $atts, $content ){
	extract(shortcode_atts(array(
	'title' => 'Collapse',
	'id'  => false,
	'class' => false,
	), $atts));  

	$GLOBALS['question'][] = array( 
	'title'   =>  esc_attr($title) ,
	'id'    =>  esc_attr($id),
	'content' =>  $content ,
	);
	
	foreach( $GLOBALS['question'] as $faq ){     
	$faq_title = preg_replace('/[^a-zA-Z0-9._\-]/', '', strtolower($faq['title'])  );   
	$return = sprintf( "\n".'    
	  <h2>%s ?</h2>      
	  <p>%s</p>'."\n" , $faq['title'], str_replace("<br />","",$faq['content'])
	);    
	} // foreach    

  return do_shortcode($return);
  
}// function ending

add_shortcode( 'faq', 'dentistry_plugin_sc_faq' );
function dentistry_plugin_sc_faq( $atts, $content ){ 
  
  if(isset( $GLOBALS['faq_count'] )) {
    $GLOBALS['faq_count']++;
  }else {
    $GLOBALS['faq_count'] = 0; 
  }
  $id  = "faq-boxes-id-".$GLOBALS['faq_count'];

  return  do_shortcode(sprintf('<div class="faq_boxes" id="%s"> %s </div>', esc_attr($id), str_replace("<br />","",$content)));
}

/********************************************/
/*
/*    OWL IMAGE shorcode.
/*
/********************************************/

add_shortcode( 'owl-img', 'dentistry_plugin_sc_owl_img' );
function dentistry_plugin_sc_owl_img( $atts, $content ){ 
	if(!empty($atts['src']))
	{
		$content='<div class="item"><img src="'.esc_url($atts['src']).'" class="img-responsive" alt=""></div>';
	}
	else
	{
		$content='<div class="item"></div>';
	}

    return sprintf( 
      '%s',
      do_shortcode( $content )
    );
}

/********************************************/
/*
/*		owl-gallery
/*
/********************************************/

add_shortcode( 'owl-gallery', 'dentistry_plugin_sc_owl_gallery' );
function dentistry_plugin_sc_owl_gallery( $atts, $content ){	
    return sprintf( 
      '<div class="owl-controls tp-gallery-box" id="gallery"> %s </div>',
      do_shortcode( str_replace("<br />", "", $content) )
    );
}

/********************************************/
/*
/*		tp-space100
/*
/********************************************/

add_shortcode( 'tp-space100', 'dentistry_plugin_sc_tp_space100' );
function dentistry_plugin_sc_tp_space100( $atts, $content ){	
    return sprintf( 
      '<div class="tp-space100">%s</div>',
      do_shortcode( str_replace("<br />", "", $content) )
    );
}

/********************************************/
/*
/*		tp-space60
/*
/********************************************/

add_shortcode( 'tp-space60', 'dentistry_plugin_sc_tp_space60' );
function dentistry_plugin_sc_tp_space60( $atts, $content ){	
    return sprintf( 
      '<div class="tp-space60">%s</div>',
      do_shortcode( str_replace("<br />", "", $content) )
    );
}

/********************************************/
/*
/*		tp-space80
/*
/********************************************/

add_shortcode( 'tp-space80', 'dentistry_plugin_sc_tp_space80' );
function dentistry_plugin_sc_tp_space80( $atts, $content ){	
    return sprintf( 
      '<div class="tp-space80">%s</div>',
      do_shortcode( str_replace("<br />", "", $content) )
    );
}

/********************************************/
/*
/*    Careers block
/*
/********************************************/

add_shortcode( 'careers-block', 'dentistry_plugin_sc_careers_block' );
function dentistry_plugin_sc_careers_block()
{
	$args = array( 'post_type' => 'career' , 'posts_per_page' => -1 , 'orderby' => 'menu_order ID','order' => 'ASC','post_status'=> 'publish' );
	$loop = new WP_Query( $args );

	$content= "";
	$total_element=count($loop->posts);

	if($loop->have_posts())			
	{
		$i=1;
		$k=0;
		while ( $loop->have_posts() ) : $loop->the_post();

		$location_html='';
		$postid = get_the_ID();
		$clinic_address=get_post_meta( $postid, 'clinic_address', true );
		
		if(($k%4)==0)
		{
			$k=0;
		}

		if(!empty($clinic_address))
		{
			$location_html = '<div class="location"> <i class="fa fa-map-marker"></i><small>'.$clinic_address.'</small></div>';
		}

		if(($k%3)==0)
		{
			$box_class="tp-dark-box";
		}
		else{
			$box_class="tp-light-box";
		}

		$content .= '<div class="col-md-6 '.$box_class.' job-post">
		<div class="space-block">
		<h3><a href="'.get_permalink( $postid).'">'.get_the_title( $postid).'</a></h3>'.$location_html.'<p>'.get_the_excerpt().'</p>
		<a href="'.get_permalink( $postid).'">'.__( 'Read More', 'dentistry').'</a></div>
		</div>';		
		
		if(($i%2)==0 && $i<$total_element)
		{
			$content .=  '</div><div class="row">';
		}	
		
		$i++;
		$k++;
		endwhile;
		wp_reset_postdata();		
	}
    return  do_shortcode(sprintf('<div class="row"> %s </div>', $content));	
}

/********************************************/
/*
/*    blog-block shorcode.
/*
/********************************************/

add_shortcode( 'blog-block', 'dentistry_plugin_sc_blog_block' );
function dentistry_plugin_sc_blog_block($atts)
{
	if(!empty($atts['title']))
	{
		$main_title=$atts['title'];

		$title_box='<div class="row"><div class="col-md-12 tp-title-center"><h1>'.$main_title.'</h1>';
				if(!empty($atts['sub-title']))
				{
					$title_box.='<p>'.esc_html($atts['sub-title']).'</p>';
				}

		$title_box .='</div></div>';
	}
	else
	{
		$title_box='';
	}

	$args = array( 'post_type' => 'post' , 'posts_per_page' => -1 , 'orderby' => 'menu_order ID','order' => 'DESC','post_status'=> 'publish' );
	$loop = new WP_Query( $args );

	$content= "";
	$i=0;

	if($loop->have_posts())		
	{
		while ( $loop->have_posts() ) : $loop->the_post();
		
		$postid = get_the_ID();
		if(get_the_post_thumbnail($postid))
		{
		
			if($i<3)	
			{
			$posted_on = sprintf(
				esc_html_x( 'On %s /', 'post date', 'dentistry' ),
				'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' .get_the_date() . '</a>'
			);			
			
			$byline = sprintf(
				esc_html_x( 'By %s /', 'post author', 'dentistry' ),
				'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
			);

		
			if ( comments_open() ) {
				$comments= (get_comments_number()==1?(get_comments_number().' Comment'):(get_comments_number().' Comments'));
				$comment_count = '<span class="comment"><a href="'.get_comments_link().'">'.$comments.'</a></span>';
			}			
			
			$content .= '<div class="col-md-4 tp-news-block">
        <div class="effect-pic"><a href="'.get_permalink($postid).'">'.get_the_post_thumbnail($postid,'full',array('class'=>'img-responsive')).'</a> </div>
        <h2><a href="'.get_permalink($postid).'">'.get_the_title($postid).'</a></h2>
        <div class="post-meta"> <span class="date-meta">'.$posted_on.'</span> <span class="admin-meta">'.$byline.'</span>  '.$comment_count.'</div>
       <p>'.get_the_excerpt().'</p>
        <a href="'.get_permalink($postid).'" class="btn tp-btn-default">'.__( 'Read More', 'dentistry').'</a> </div>';
			$i++;
			}
		
		}
		endwhile;
		wp_reset_postdata();		
	}
    return  do_shortcode(sprintf('<div class="tp-section"><div class="container">%s<div class="row"> %s </div></div></div>', $title_box, $content));		
}

/********************************************/
/*
/*    testimonial-block shortcode.
/*
/********************************************/

add_shortcode( 'testimonial-block', 'dentistry_plugin_sc_testimonial_block' );
function dentistry_plugin_sc_testimonial_block($atts)
{

	if(!empty($atts['title']))
	{
		$main_title=$atts['title'];

		$title_box='<div class="row"><div class="col-md-12 tp-title-center"><h1>'.$main_title.'</h1>';
				if(!empty($atts['sub-title']))
				{
					$title_box.='<p>'.esc_html($atts['sub-title']).'</p>';
				}

		$title_box .='</div></div>';

	}
	else
	{
		$title_box='';
	}
		
	$args = array( 'post_type' => 'testimonial' , 'posts_per_page' => -1 , 'orderby' => 'menu_order ID','order' => 'ASC','post_status'=> 'publish' );
	$testimonial = new WP_Query( $args );

	$content= "";
	if($testimonial->have_posts())		
	{
		while ( $testimonial->have_posts() ) : $testimonial->the_post();
		
		$postid = get_the_ID();

		$content .= '<div class="item patient">
          <div class="patient-quote">
            <p>'.get_post_meta( $postid, 'testimonials_details', true ).'</p>
          </div>
          <div class="patient-info">
            <div class="patient-pic">'.get_the_post_thumbnail($postid,'full',array('class'=>'img-responsive')).'</div>
            <h3>'.get_the_title( $postid ).'</h3>
            <small>'.get_post_meta( $postid, 'testimonials_treatment', true ).'</small> </div>
        </div>';

		endwhile;
		wp_reset_postdata();		
	}
    return  do_shortcode(sprintf('<div class="tp-section"><div class="container">%s<div class="row"><div class="col-md-12 owl-carousel tp-testimonial-box">%s </div></div></div></div>',$title_box, $content));		
}


/********************************************/
/*
/*    testimonial-block Single Center shortcode.
/*
/********************************************/

add_shortcode( 'testimonial-single-center-block', 'dentistry_plugin_sc_testimonial_single_center_block' );
function dentistry_plugin_sc_testimonial_single_center_block($atts)
{

	if(!empty($atts['title']))
	{
		$main_title=$atts['title'];

		$title_box='<div class="row"><div class="col-md-12 tp-title-center"><h1>'.$main_title.'</h1>';
				if(!empty($atts['sub-title']))
				{
					$title_box.='<p>'.esc_html($atts['sub-title']).'</p>';
				}

		$title_box .='</div></div>';

	}
	else
	{
		$title_box='';
	}
		
	$args = array( 'post_type' => 'testimonial' , 'posts_per_page' => -1 , 'orderby' => 'menu_order ID','order' => 'ASC','post_status'=> 'publish' );
	$testimonial = new WP_Query( $args );

	$content= "";
	if($testimonial->have_posts())		
	{
		while ( $testimonial->have_posts() ) : $testimonial->the_post();
		
		$postid = get_the_ID();

		$content .= '<div class="item patient text-center">
          <div class="patient-pic">'.get_the_post_thumbnail($postid,'full',array('class'=>'img-responsive img-circle')).'</div>
          <div class="patient-quote">
            <p>'.get_post_meta( $postid, 'testimonials_details', true ).'</p>
          </div>
          <div class="patient-info">
            <h3>'.get_the_title( $postid ).'</h3>
            <small>'.get_post_meta( $postid, 'testimonials_treatment', true ).'</small> </div>
        </div>';

		endwhile;
		wp_reset_postdata();		
	}
    return  do_shortcode(sprintf('<div class="tp-section single-testimonial"><div class="container">%s<div class="row"><div class="col-md-offset-2 col-md-8"><div class="owl-carousel tp-testimonial-box">%s </div></div></div></div></div>',$title_box, $content));		
}



/********************************************/
/*
/*    testimonial-Two block shortcode.
/*
/********************************************/

add_shortcode( 'testimonial-two-block', 'dentistry_plugin_sc_testimonial_two_block' );
function dentistry_plugin_sc_testimonial_two_block($atts)
{

	if(!empty($atts['title']))
	{
		$main_title=$atts['title'];

		$title_box='<div class="row"><div class="col-md-12 tp-title-center"><h1>'.$main_title.'</h1>';
				if(!empty($atts['sub-title']))
				{
					$title_box.='<p>'.esc_html($atts['sub-title']).'</p>';
				}

		$title_box .='</div></div>';

	}
	else
	{
		$title_box='';
	}
		
	$args = array( 'post_type' => 'testimonial' , 'posts_per_page' => -1 , 'orderby' => 'menu_order ID','order' => 'ASC','post_status'=> 'publish' );
	$testimonial = new WP_Query( $args );

	$content= "";
	if($testimonial->have_posts())		
	{
		while ( $testimonial->have_posts() ) : $testimonial->the_post();
		
		$postid = get_the_ID();

		$content .= '<div class="item patient"><div class="testimonial-block tp-grey-box testimonial">
            <div class="testimonial-pic">'.get_the_post_thumbnail($postid,'full',array('class'=>'img-responsive img-circle')).'</div>
            <div class="testimonial-info-right">
              <p class="patient-review">"'.get_post_meta( $postid, 'testimonials_details', true ).'"</p>
              <h3 class="testimonial-name">'.get_the_title( $postid ).'</h3>
              <span class="treatement">'.get_post_meta( $postid, 'testimonials_treatment', true ).'</span> </div>
          </div></div>';


		endwhile;
		wp_reset_postdata();		
	}
    return  do_shortcode(sprintf('<div class="tp-section"><div class="container">%s<div class="row"><div class="col-md-12 owl-carousel tp-testimonial-two">%s </div></div></div></div>',$title_box, $content));		
}




/********************************************/
/*
/*    testimonial-Two OUTSIDE block shortcode.
/*
/********************************************/

add_shortcode( 'testimonial-two-outside-block', 'dentistry_plugin_sc_testimonial_two_outside_block' );
function dentistry_plugin_sc_testimonial_two_outside_block($atts)
{

	if(!empty($atts['title']))
	{
		$main_title=$atts['title'];

		$title_box='<div class="row"><div class="col-md-12 tp-title-center"><h1>'.$main_title.'</h1>';
				if(!empty($atts['sub-title']))
				{
					$title_box.='<p>'.esc_html($atts['sub-title']).'</p>';
				}

		$title_box .='</div></div>';

	}
	else
	{
		$title_box='';
	}
		
	$args = array( 'post_type' => 'testimonial' , 'posts_per_page' => -1 , 'orderby' => 'menu_order ID','order' => 'ASC','post_status'=> 'publish' );
	$testimonial = new WP_Query( $args );

	$content= "";
	if($testimonial->have_posts())		
	{
		while ( $testimonial->have_posts() ) : $testimonial->the_post();
		
		$postid = get_the_ID();

		$content .= '<div class="item patient"><div class="testimonial-innber-box tp-grey-box">
		<p class="patient-review">"'.get_post_meta( $postid, 'testimonials_details', true ).'"</p>
          </div>            
		  <div class="testimonial-info-left">
              <div class="testimonial-pic">'.get_the_post_thumbnail($postid,'full',array('class'=>'img-responsive img-circle')).'</div>
              <div class="testimonial-clint-box">
			  <h3 class="testimonial-name">'.get_the_title( $postid ).'</h3>
              <span class="treatement">'.get_post_meta( $postid, 'testimonials_treatment', true ).'</span> </div></div></div>';

		endwhile;
		wp_reset_postdata();		
	}
    return  do_shortcode(sprintf('<div class="tp-section"><div class="container">%s<div class="row"><div class="col-md-12 owl-carousel tp-testimonial-two">%s </div></div></div></div>',$title_box, $content));		
}






/********************************************/
/*
/*    testimonial boxes block shortcode.
/*
/********************************************/

add_shortcode( 'testimonial-boxes-block', 'dentistry_plugin_sc_testimonial_boxes_block' );
function dentistry_plugin_sc_testimonial_boxes_block($atts)
{
	$args = array( 'post_type' => 'testimonial', 'posts_per_page' => -1 , 'orderby' => 'menu_order ID','order' => 'ASC','post_status'=> 'publish' );
	$testimonial = new WP_Query( $args );

	$content= "";
	$i=1;
	$total_element=count($testimonial->posts);

	if($testimonial->have_posts())		
	{
		while ( $testimonial->have_posts() ) : $testimonial->the_post();

		$postid = get_the_ID();
		$content .= '<div class="col-md-6 testimonial-box">
					<div class="space-block tp-grey-box">
					  <p class="patient-comment">'.get_post_meta( $postid, 'testimonials_details', true ).'</p>
					  <div class="testimonial-pic">'.get_the_post_thumbnail($postid,'full',array('class'=>'img-responsive')).'</div>
					  <div class="testimonial-info">
						<h3>'.get_the_title( $postid ).'</h3>
						<p class="treatement">'.get_post_meta( $postid, 'testimonials_treatment', true ).'</p>
					  </div>
					</div>
				  </div>';

		if(($i%2)==0 && $i<$total_element)
		{
			$content .= '</div><div class="row">';
		}	

		$i++;
		endwhile;
		wp_reset_postdata();		
	}
    return  do_shortcode(sprintf('<div class="row">%s</div>',$content));		
}


/********************************************/
/*
/*    Doctor -block shorcode.
/*
/********************************************/

add_shortcode( 'doctors-block', 'dentistry_plugin_sc_doctors_block' );
function dentistry_plugin_sc_doctors_block($atts)
{
    $args = array( 'post_type' => 'doctor', 'posts_per_page' => 4,'orderby' => 'menu_order ID','order'   => 'ASC' );
	$doctors = new WP_Query( $args );
    
	if(!empty($atts['title']))
	{
		$main_title=$atts['title'];
		$sub_title=$atts['sub-title'];

		$title_box='<div class="container"><div class="row"><div class="col-md-12 tp-title-center"><h1>'.$main_title.'</h1>';
				if(!empty($sub_title))
				{
					$title_box.='<p>'.esc_html($sub_title).'</p>';
				}

		$title_box .='</div></div></div>';
	}
	else
	{
		$title_box='';
	}	

	$content= "";
	if($doctors->have_posts())		
	{
		$i=1;
		while ( $doctors->have_posts() ) : $doctors->the_post();
		
		$postid = get_the_ID();
		 
		$meta_doctor_designation = get_post_meta( $postid , 'doctor_designation', true );
		if($meta_doctor_designation)
		{
			 $doctor_designation_html = '<span class="designation">'.esc_html($meta_doctor_designation).'</span>';
		}

		if(($i%2)==0)
		{
			$box_class="tp-light-box";
		}
		else{
			$box_class="tp-dark-box";
		}

		$content .= '<div class="col-md-3 no-padding tp-doctor-block"><div class="effect-pic">
          <a href="'.get_permalink($postid).'">'.get_the_post_thumbnail($postid,'full',array('class'=>'img-responsive')).'</a></div>
          <div class="tp-dc-info '.$box_class.'">
            <h2><a href="'.get_permalink($postid).'">'.get_the_title($postid).'</a></h2>
            '.$doctor_designation_html.' </div>
        </div>';     
		
		$i++;
		endwhile;
		wp_reset_postdata();		
	}
    return  do_shortcode(sprintf('<div class="tp-section">%s<div class="container-fluid"><div class="row">%s </div></div></div>',$title_box , $content));		
}

/********************************************/
/*
/*    Doctor -block shorcode.
/*
/********************************************/

add_shortcode( 'doctors-four-block', 'dentistry_plugin_sc_doctors_four_block' );
function dentistry_plugin_sc_doctors_four_block($atts)
{

	$atts = shortcode_atts( array(
      "block" => 4,
      "class" => false,	 
      "title" => false,
	  "sub-title" => false,	  
	), $atts );	
 
	if($atts['class']=='light-dark')
	{
		$base_class='tp-light-boxes';	
	}
	else
	{
		$base_class='tp-base';	
	}	

	if($atts['block']==4)
	{
		$col_md_class='col-md-3';	
	}
	else if($atts['block']==2)
	{
		$col_md_class='col-md-6';	
	}
	else if($atts['block']==3)
	{
		$col_md_class='col-md-4';	
	}
	else{
		$col_md_class='col-md-3';			
	}
	
    $args = array( 'post_type' => 'doctor', 'posts_per_page' => $atts['block'],'orderby' => 'menu_order ID','order'   => 'ASC' );
	$doctors = new WP_Query( $args );
    
	if(!empty($atts['title']))
	{
		$main_title=$atts['title'];
		$sub_title=$atts['sub-title'];

		$title_box='<div class="row"><div class="col-md-offset-2 col-md-8 tp-title-center"><h1>'.$main_title.'</h1>';
				if(!empty($sub_title))
				{
					$title_box.='<p>'.esc_html($sub_title).'</p>';
				}

		$title_box .='</div></div>';
	}
	else
	{
		$title_box='';
	}	

	$content= "";
	if($doctors->have_posts())		
	{
		$i=1;
		while ( $doctors->have_posts() ) : $doctors->the_post();
		
		$postid = get_the_ID();
		 
		$meta_doctor_designation = get_post_meta( $postid , 'doctor_designation', true );
		if($meta_doctor_designation)
		{
			 $doctor_designation_html = '<span class="designation">'.esc_html($meta_doctor_designation).'</span>';
		}


		$content .= '<div class="'.$col_md_class.' tp-doctor-block"><div class="effect-pic">
          <a href="'.get_permalink($postid).'">'.get_the_post_thumbnail($postid,'full',array('class'=>'img-responsive')).'</a></div>
          <div class="tp-dc-info doctor-four">
            <h2><a href="'.get_permalink($postid).'">'.get_the_title($postid).'</a></h2>
            '.$doctor_designation_html.'
			 </div>
        </div>';     
		
		$i++;
		endwhile;
		wp_reset_postdata();		
	}
    return  do_shortcode(sprintf('<div class="tp-section %s"><div class="container">%s<div class="row">%s </div></div></div>',$base_class,$title_box , $content));		
}
/********************************************/
/*
/*    Doctor -block shorcode.
/*
/********************************************/

add_shortcode( 'doctors-two-block', 'dentistry_plugin_sc_doctors_two_block' );
function dentistry_plugin_sc_doctors_two_block($atts)
{
    $args = array( 'post_type' => 'doctor', 'posts_per_page' => 2,'orderby' => 'menu_order ID','order'   => 'ASC' );
	$doctors = new WP_Query( $args );
    
	if(!empty($atts['title']))
	{
		$main_title=$atts['title'];
		$sub_title=$atts['sub-title'];

		$title_box='<div class="row"><div class="col-md-offset-2 col-md-8 tp-title-center"><h1>'.$main_title.'</h1>';
				if(!empty($sub_title))
				{
					$title_box.='<p>'.esc_html($sub_title).'</p>';
				}

		$title_box .='</div></div>';
	}
	else
	{
		$title_box='';
	}	

	$content= "";
	if($doctors->have_posts())		
	{
		$i=1;
		while ( $doctors->have_posts() ) : $doctors->the_post();
		
		$postid = get_the_ID();
		 
		$meta_doctor_designation = get_post_meta( $postid , 'doctor_designation', true );
		if($meta_doctor_designation)
		{
			 $doctor_designation_html = '<span class="designation">'.esc_html($meta_doctor_designation).'</span>';
		}


		$content .= '<div class="col-md-6">
		<div class="two-doctor-block">
<div class="row">
              <div class="col-md-5">
                <div class="effect-pic"><a href="'.get_permalink($postid).'">'.get_the_post_thumbnail($postid,'full',array('class'=>'img-responsive')).'</a></div>
              </div>
              <div class="col-md-7">
                <div class="tp-dc-info">
                  <h2><a href="'.get_permalink($postid).'">'.get_the_title($postid).'</a></h2>
                  '.$doctor_designation_html.'
                   <p>'.get_the_excerpt().'</p>
                  <a href="'.get_permalink($postid).'" class="tp-btn-link">'.esc_html__('Read More','dentistry').'</a> </div>
              </div>
            </div>
			</div>
        </div>';     
		
		$i++;
		endwhile;
		wp_reset_postdata();		
	}
    return  do_shortcode(sprintf('<div class="tp-section tp-light-boxes"><div class="container">%s<div class="row">%s </div></div></div>',$title_box , $content));		
}


/********************************************/
/*
/*		Services Block.
/*
/********************************************/

add_shortcode( 'services-block', 'dentistry_plugin_sc_services_block' );
function dentistry_plugin_sc_services_block( $atts, $content ){	   

	$args = array( 'post_type' => 'service','posts_per_page' => 6,'orderby' => 'menu_order ID','order'   => 'ASC');	
	$service = new WP_Query( $args );

	$content= "";
	if($service->have_posts())	
	{
		$i=0;
		while ( $service->have_posts() ) : $service->the_post();
		
		$postid = get_the_ID();

		$service_data = get_post_meta( $postid, 'service_data', true );	
		$service_icon_type = get_post_meta( $postid, 'service_icon_type', true );	

		if(isset($service_icon_type) && !empty($service_icon_type))
		{
			$service_icon_html = '<div class="service-six-icon service-icon">
            <i class="'.$service_icon_type.'"></i>
            </div>';
		}
		else if(isset($service_data['service_icon']))
		{
			$service_icon_html = '<div class="service-icon">
            <img src="'.esc_url($service_data['service_icon']).'"  class="img-responsive" alt="">
            </div>';
		}		
		else
		{
			$service_icon_html = '';
		}	
		
		if(($i%2)==0)
		{
			$box_class="tp-light-box";
		}
		else{
			$box_class="tp-dark-box";
		}
		
		 
		$content .= '<div class="col-md-2 '.$box_class.' tp-service-blk">
        '.$service_icon_html.'
        <h2><a href="'.get_permalink($postid).'">'.get_the_title($postid).'</a></h2>
        <p>'.get_the_excerpt().'</p>
        <a href="'.get_permalink($postid).'" class="link">'.__( 'Read More', 'dentistry').'</a> </div>';	  

		$i++;
		endwhile;
		wp_reset_postdata();		
	}

    return  do_shortcode(sprintf('<div class="container-fluid"><div class="row">%s</div></div>', $content));		
}

/********************************************/
/*
/*		Services left-icon Block.
/*
/********************************************/

add_shortcode( 'services-left-icon-block', 'dentistry_plugin_sc_services_left_icon_block' );
function dentistry_plugin_sc_services_left_icon_block( $atts, $content ){  

	if(!empty($atts['title']))
	{
		$main_title=$atts['title'];

		$title_box='<div class="row"><div class="col-md-12 tp-title-center"><h1>'.$main_title.'</h1>';
				if(!empty($atts['sub-title']))
				{
					$title_box.='<p>'.esc_html($atts['sub-title']).'</p>';
				}
		$title_box .='</div></div>';
	}
	else
	{
		$title_box='';
	}

	$args = array( 'post_type' => 'service','posts_per_page' => 6,'orderby' => 'menu_order ID','order'   => 'ASC');	
	$service = new WP_Query( $args );
	$total_element=count($service->posts);

	$i=1;
	$content= "";
	if($service->have_posts())
	{
		while ( $service->have_posts() ) : $service->the_post();
		
		$postid = get_the_ID();

		$service_data = get_post_meta( $postid, 'service_data', true );	
		$service_icon_type = get_post_meta( $postid, 'service_icon_type', true );	

		if(isset($service_icon_type) && !empty($service_icon_type))
		{
			$service_icon_html = '<div class="service-left-icon service-icon">
            <i class="'.$service_icon_type.'"></i>
            </div>';
		}
		else if(isset($service_data['service_icon']))
		{
			$service_icon_html = '<div class="service-left-icon service-icon">
            <img src="'.esc_url($service_data['service_icon']).'"  class="img-responsive" alt="">
            </div>';
		}		
		else
		{
			$service_icon_html = '';
		}			

		$content .= '<div class="col-md-4 service-block"><!-- service block -->
			<div class="left-icon-service">	
          '.$service_icon_html.'
          <div class="service-right-info">
            <h2><a href="'.get_permalink($postid).'">'.get_the_title($postid).'</a></h2>
            <p>'.get_the_excerpt().'</p>
            <a class="tp-btn-link" href="'.get_permalink($postid).'">'.__( 'Read More', 'dentistry').'</a></div>
        </div></div>';
		

		if(($i%3)==0 && $i<$total_element)
		{
			$content .=  '</div><div class="row">';
		}	
		
		$i++;		

		endwhile;
		wp_reset_postdata();		
	}

    return  do_shortcode(sprintf('<div class="tp-section"><div class="container">%s<div class="row service_sc">%s</div></div></div>', $title_box, $content));		
}

/********************************************/
/*
/*		Services left-icon Block.
/*
/********************************************/

add_shortcode( 'services-thumbnail-block', 'dentistry_plugin_sc_services_thumbnail_block' );
function dentistry_plugin_sc_services_thumbnail_block( $atts, $content ){  

	if(!empty($atts['title']))
	{
		$main_title=$atts['title'];

		$title_box='<div class="row"><div class="col-md-12 tp-title-center"><h1>'.$main_title.'</h1>';
				if(!empty($atts['sub-title']))
				{
					$title_box.='<p>'.esc_html($atts['sub-title']).'</p>';
				}
		$title_box .='</div></div>';
	}
	else
	{
		$title_box='';
	}

	$args = array( 'post_type' => 'service','posts_per_page' => -1,'orderby' => 'menu_order ID','order'   => 'ASC');	
	$service = new WP_Query( $args );
	$total_element=count($service->posts);

	$content= '';
	if($service->have_posts())
	{
		while ( $service->have_posts() ) : $service->the_post();
		
		$postid = get_the_ID();

		$service_data = get_post_meta( $postid, 'service_data', true );	
		$service_icon_type = get_post_meta( $postid, 'service_icon_type', true );	

		if(isset($service_icon_type) && !empty($service_icon_type))
		{
			$service_icon_html = '<div class="service-caption service-icon">
            <i class="'.$service_icon_type.'"></i>
            </div>';
		}
		else if(isset($service_data['service_icon']))
		{
			$service_icon_html = '<div class="service-caption service-icon">
            <img src="'.esc_url($service_data['service_icon']).'"  class="img-responsive" alt="">
            </div>';
		}		
		else
		{
			$service_icon_html = '';
		}			

		$content .= '<div class="col-md-12 service-block item">
          <div class="service-pic">
          <div class="effect-pic">
          <a href="'.get_permalink($postid).'">
          	'.get_the_post_thumbnail($postid,'full',array('class'=>'img-responsive')).'  
          </a>
          </div>
          '.$service_icon_html.'  
          </div>
          <div class="tp-section-service thumbnail-space-block">
            <h2><a href="'.get_permalink($postid).'">'.get_the_title($postid).'</a></h2>
            <p>'.get_the_excerpt().'</p>
            <a href="<?php the_permalink(); ?>">'.__( 'Read More', 'dentistry').'</a>             
            </div>
        </div>';

		endwhile;
		wp_reset_postdata();		
	}

    return  do_shortcode(sprintf('<div class="tp-section"><div class="container">%s<div class="row service_sc"><div class="tp-thumbnail-slide" id="tp-thumbnail-slide">%s</div></div></div></div>', $title_box, $content));		
}



/********************************************/
/*
/*		Services Block.
/*
/********************************************/

add_shortcode( 'services-six-block', 'dentistry_plugin_sc_services_six_block' );
function dentistry_plugin_sc_services_six_block( $atts, $content ){	   

	$args = array( 'post_type' => 'service','posts_per_page' => 6,'orderby' => 'menu_order ID','order'   => 'ASC');	
	$service = new WP_Query( $args );

	$content= "";
	if($service->have_posts())	
	{
		$i=0;
		while ( $service->have_posts() ) : $service->the_post();
		
		$postid = get_the_ID();

		$service_data = get_post_meta( $postid, 'service_data', true );	

		$service_icon_type = get_post_meta( $postid, 'service_icon_type', true );	
		if(isset($service_icon_type) && !empty($service_icon_type))
		{
			$service_icon_html = '<div class="service-icon">
            <i class="'.$service_icon_type.'"></i>
            </div>';
		}
		else if(isset($service_data['service_icon']))
		{
			$service_icon_html = '<div class="service-icon service-six-img">
            <img src="'.esc_url($service_data['service_icon']).'"  class="img-responsive" alt="">
            </div>';
		}		
		else
		{
			$service_icon_html = '';
		}	
		
		$content .= '<div class="col-md-2  col-sm-4 service-six-blk">
        '.$service_icon_html.'
        <h3><a href="'.get_permalink($postid).'">'.get_the_title($postid).'</a></h3>
 		</div>';	  

		$i++;
		endwhile;
		wp_reset_postdata();		
	}

    return  do_shortcode(sprintf('<div class="container-fluid"><div class="row">%s</div></div>', $content));		
}

/********************************************/
/*
/*		Services Three Block.
/*
/********************************************/

add_shortcode( 'services-three-block', 'dentistry_plugin_sc_three_services_block' );
function dentistry_plugin_sc_three_services_block( $atts, $content ){  

	if(!empty($atts['title']))
	{
		$main_title=$atts['title'];

		$title_box='<div class="row"><div class="col-md-12 tp-title-center"><h1>'.$main_title.'</h1>';
				if(!empty($atts['sub-title']))
				{
					$title_box.='<p>'.esc_html($atts['sub-title']).'</p>';
				}
		$title_box .='</div></div>';
	}
	else
	{
		$title_box='';
	}

	$args = array( 'post_type' => 'service','posts_per_page' => 6,'orderby' => 'menu_order ID','order'   => 'ASC');	
	$service = new WP_Query( $args );

	$content= "";
	if($service->have_posts())
	{
		$i=0;
		while ( $service->have_posts() ) : $service->the_post();
		
		$postid = get_the_ID();

		$service_data = get_post_meta( $postid, 'service_data', true );	
		$service_icon_type = get_post_meta( $postid, 'service_icon_type', true );	

		if(isset($service_icon_type) && !empty($service_icon_type))
		{
			$service_icon_html = '<div class="service-three-icon service-icon">
            <i class="'.$service_icon_type.'"></i>
            </div>';
		}
		else if(isset($service_data['service_icon']))
		{
			$service_icon_html = '<div class="service-icon">
            <img src="'.esc_url($service_data['service_icon']).'"  class="img-responsive" alt="">
            </div>';
		}		
		else
		{
			$service_icon_html = '';
		}		
		
		if(($i%2)==0)
		{
			$box_class="tp-light-box";
		}
		else{
			$box_class="tp-dark-box";
		}		
		 
		$content .= '<div class="col-md-4 '.$box_class.' tp-service-blk tp-service-box">
        '.$service_icon_html.'
        <h2><a href="'.get_permalink($postid).'">'.get_the_title($postid).'</a></h2>
        <p>'.get_the_excerpt().'</p>
        <a href="'.get_permalink($postid).'" class="link">'.__( 'Read More', 'dentistry').'</a> </div>';	  

		$i++;
		endwhile;
		wp_reset_postdata();		
	}

    return  do_shortcode(sprintf('%s<div class="row service_sc">%s</div>', $title_box, $content));		
}


/********************************************/
/*
/*		Price List Block.
/*
/********************************************/

add_shortcode( 'price-list-call', 'dentistry_plugin_sc_price_list_call' );
function dentistry_plugin_sc_price_list_call( $atts, $content ){

	$args = array( 'post_type' => 'service','posts_per_page' => -1,'orderby' => 'menu_order ID','order'   => 'ASC');	
	$service = new WP_Query( $args );

	$content= '';
	$service_price_html='';
	if($service->have_posts())	
	{
		$i=0;
		while ( $service->have_posts() ) : $service->the_post();
		
		$postid = get_the_ID();

		$service_price = get_post_meta( $postid, 'service_price', true );	

		if(!empty($service_price))
		{
			$service_price_html='<div class="service-price-amount">'.esc_html(dentistry_tg_get_option('currency_symbols')).$service_price.'</div>';
		}		
		
		$content .= '<div class="col-md-4">
		<div class="service-price">
        '.$service_price_html.'
        <h3>'.get_the_title($postid).'</h3>
 		</div></div>';	  

		$i++;
		endwhile;
		wp_reset_postdata();		
	}


    return sprintf( 
	  '<div class="parallax-price parallax" style="background-image: linear-gradient(rgba(40, 40, 40, 0.8), rgba(40, 40, 40, 0.8)),url(%s);">
	  <div class="container">	
	  <div class="row">
			<div class="col-md-offset-2 col-md-8 tp-title-center">
				<h1>%s</h1>
				<p>%s</p>
			</div>
			
        </div><div class="row">%s</div></div></div>',
	  $atts['bg-image'],	
      $atts['title'],
	  $atts['sub-title'],
      do_shortcode( $content )
    );
}


/********************************************/
/*
/*		CTA Block.
/*
/********************************************/

add_shortcode( 'cta-call', 'dentistry_plugin_sc_cta_call' );
function dentistry_plugin_sc_cta_call( $atts, $content ){	    
    return sprintf( 
	  '<div class="row service-cta">
			<div class="col-md-2 cta-icon"><img alt="" src="%s"></div>
			<div class="col-md-6 cta-info">
				<h1>%s</h1>
				<p>%s</p>
			</div>
			
			<div class="col-md-4 white-btn">	
				<a class="tp-btn tp-btn-white" href="%s">%s</a>
			</div>
        </div>',
	  $atts['icon-image'],	
      $atts['title'],
	  $atts['sub-title'],
	  $atts['button-url1'],
	  $atts['button-title1'],
      do_shortcode( $content )
    );
}
?>