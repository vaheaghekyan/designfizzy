<?php     
/**
 * Plugin Name:     Dentistry Code
 * Plugin URI:      #
 * Github URI:      #
 * Description:     Dentistry Code plugin is used for Custom post type,short code and import data for Dentistry theme integration
 * Author:          Udayraj Khatri
 * Author URI:      http://thegenius.co
 * Version:         1.0.0
 * Text Domain:
 * License:         #   
 * License URI:     #
 * Domain Path:     #
 *
 * @package         Code
 * @author          #
 * @license         #
 * @copyright       #
 */
global $plugin_domain;
$plugin_domain = 'dentistry';
define( 'DENTISTRT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
 
class Dentistry_Plugin_Setup_Plan
{
    static $detect;
    static function  init()
    {
        require_once(DENTISTRT_PLUGIN_DIR.'/core/icon-array.php');
        require_once(DENTISTRT_PLUGIN_DIR.'/plugin.importer.php');
		require_once(DENTISTRT_PLUGIN_DIR.'/core/custom-post.php');
		require_once(DENTISTRT_PLUGIN_DIR.'/core/shortcodes.php');
        require_once(DENTISTRT_PLUGIN_DIR.'/core/shortcode-function.php');
    }
    static  function dentistry_plugin_setup_url($u=false)
    {
        if($u){
            $u='/'.$u;
        }
        return plugin_dir_url(__FILE__).$u;
    }
    static  function dentistry_plugin_setup_dir($u=false){
        if($u){
            $u='/'.$u;
        }
        return plugin_dir_path(__FILE__).$u;
    }
}

add_action( 'plugins_loaded', array('Dentistry_Plugin_Setup_Plan','init'));

global $setup_go;
$setup_go=new Dentistry_Plugin_Setup_Plan();
function Dentistry_Plugin_Setup_Plan(){
    return new Dentistry_Plugin_Setup_Plan();
}