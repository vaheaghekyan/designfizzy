<?php 
$main_over_menus = array(
                  "first-main-menu" => "primary",
                  );
$homepage_default="Home";
$homepost_default="Blog";
?>